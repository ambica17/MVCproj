package com.niit;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class LoginController {
	
	String message = "Success..";
	@RequestMapping("/login")
	public ModelAndView getLog()
	{
		ModelAndView mv = new ModelAndView("Login");
		mv.addObject("message",message);
		return mv;
	}
	@RequestMapping("/register")
	public ModelAndView getReg()
	{
		ModelAndView mv = new ModelAndView("Register");
		mv.addObject("message",message);
		return mv;
	}
	@RequestMapping("/img")
	public ModelAndView getImg()
	{
		ModelAndView mv = new ModelAndView("ImgClick");
		//mv.addObject("message",message);
		return mv;
	}
}
package com.niit;

import java.util.*;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class LoginController {
	
	String message = "Success..";
	@RequestMapping("/login")
	public ModelAndView getLog()
	{
		ModelAndView mv = new ModelAndView("Login");
		mv.addObject("message",message);
		return mv;
	}
	@RequestMapping("/register")
	public ModelAndView getReg()
	{
		ModelAndView mv = new ModelAndView("Register");
		mv.addObject("message",message);
		return mv;
	}
	@RequestMapping("/img")
	public ModelAndView getImg(@RequestParam(value = "name", required = false, defaultValue = "World") String name) {
			
		ModelAndView mv=null;
		if("prod1".equals(name))
		{
			 mv = new ModelAndView("ImgClick");
			mv.addObject("id",100);
			mv.addObject("name", name);
			mv.addObject("desc","c is a function oriented");
		mv.addObject("price","$25.00");
		}
		if("prod2".equals(name))
		{
			mv = new ModelAndView("ImgClick");
			mv.addObject("id",200);
			mv.addObject("name", name);
			mv.addObject("desc","java is a object oriented");
			mv.addObject("price","$35.00");
		}
		if("prod3".equals(name))
		{
			mv = new ModelAndView("ImgClick");
			mv.addObject("id",300);
			mv.addObject("name", name);
			mv.addObject("desc","oracle is a database oriented");
			mv.addObject("price","$45.00");
		}
		if("all".equals(name))
		{
			ArrayList list=new ArrayList();
			HashMap h1=new HashMap();
			h1.put("id","100");
			h1.put("name","prod1");
			h1.put("desc","c is a function oriented");
			h1.put("price","$25.00");
			list.add(h1);
			HashMap h2=new HashMap();
			h2.put("id","200");
			h2.put("name","prod2");
			h2.put("desc","java is a object oriented");
			h2.put("price","$35.00");
			list.add(h2);
			HashMap h3=new HashMap();
			h3.put("id","300");
			h3.put("name","prod3");
			h3.put("desc","sql is a database oriented");
			h3.put("price","$25.00");
			list.add(h3);
			mv=new ModelAndView("AllProducts");
			mv.addObject("products", list);
		}
		return mv;
		}
	
	
	
}